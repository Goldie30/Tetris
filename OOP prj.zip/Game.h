#pragma once
// #include<Windows.h>
#include <SFML/Graphics.hpp>
#include <iostream>
#include<fstream>
#include <string>
#include "I mino.h"
#include "J mino.h"
#include "L mino.h"
#include "O mino.h"
#include "S minoh.h"
#include "T mino.h"
#include "Z mino.h"
#include "well.h"

using namespace std;
class Game {
private:
    sf::RenderWindow* window;
    Well well;
    sf::Clock clock;
    sf::Time elapsed;
    float dropDownTime;
    Tetrimino* tetrimino;
    int randnum;
    int grid[20][10];
    int score;
    int lines;
    int level;
    int scores[5];
    string name[5];
    int screen;
public:
    Game() {
        window = new sf::RenderWindow(sf::VideoMode(800, 861), "Tetris");
        well = Well(window);
        clock.restart();
        elapsed = clock.restart();
        dropDownTime = 1.0;
        score = 0;
        lines = 0;
        level = 1;
        screen = 0;

        for (int i = 0; i < 20; i++)
            for (int j = 0; j < 10; j++)
                grid[i][j] = 0;
    }
    // line clearing
    bool isLineComplete(int row) {
        for (int j = 0; j < 10; j++) {
            if (grid[row][j] == 0)
                return false;
        }

        return true;
    }
    void clearLine(int row) {
        for (int j = 0; j < 10; j++) {
            grid[row][j] = 0;
        }

        for (int i = row - 1; i >= 0; i--) {
            for (int j = 0; j < 10; j++) {
                grid[i + 1][j] = grid[i][j];
                grid[i][j] = 0;
            }
        }
    }
    void clear() {
        for (int i = 20 - 1; i >= 0; i--) {
            if (isLineComplete(i)) {
                cout << "Line " << i << " is complete " << endl;
                clearLine(i);
                score += 100;
                lines++;
                if (lines % 10 == 0 && lines != 0 && level < 8)
                {
                    level++;
                    dropDownTime -= 0.1;
                }
                if (level == 8)
                {
                    level = 1;
                    dropDownTime = 1.0;
                }
                   
                cout << "score = " << score;
                cout << "lines = " << lines;

            }
        }
    }

    // reset game
    void gameReset() {
        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 10; j++) {
                grid[i][j] = 0;
            }
        }
        score = 0;
        lines = 0;
        level = 0;
        dropDownTime = 1.0;
    }

    void colorCell(int i, int j, int c) {
        sf::Color colour;
        int cell_size = 43;

        if (c == 1)
            colour = sf::Color::Blue;
        else if (c == 2)
            colour = sf::Color::Cyan;
        else if (c == 3)
            colour = sf::Color::Yellow;
        else if (c == 4)
            colour = sf::Color::Green;
        else if (c == 5)
            colour = sf::Color::Magenta;
        else if (c == 6)
            colour = sf::Color::Red;
        else if (c == 7)
            colour = sf::Color::White;

        sf::RectangleShape cell(sf::Vector2f(cell_size, cell_size));
        cell.setFillColor(colour);
        cell.setPosition(cell_size * i, cell_size * j);
        window->draw(cell);
    }

    void dropNewTetrimino() {
        randnum = rand() % 7;

        switch (randnum) {
        case 0:
            tetrimino = new Z(grid, window);
            break;
        case 1:
            tetrimino = new I(grid, window);
            break;
        case 2:
            tetrimino = new J(grid, window);
            break;
        case 3:
            tetrimino = new O(grid, window);
            break;
        case 4:
            tetrimino = new S(grid, window);
            break;
        case 5:
            tetrimino = new T(grid, window);
            break;
        case 6:
            tetrimino = new L(grid, window);
            break;
        }
    }
    void renderGame() {
        sf::RectangleShape bg = sf::RectangleShape(sf::Vector2f(800, 861));
        bg.setFillColor(sf::Color(0x1E0A3DFF));
        tetrimino = new I(grid, window);
        // setting text

        sf::Font font;
        sf::Text text;
        sf::Text linestext;
        sf::Text name;
        sf::Text scoretext;
        sf::Text no_lines;
        sf::Text inputname;
        sf::Text levels;
        sf::Text noLevels;

        font.loadFromFile("sigmar.ttf");
        text.setFont(font);
        text.setString("SCORE : ");
        text.setFillColor(sf::Color::White);
        text.setCharacterSize(50);
        text.setPosition(460, 350);

        linestext.setFont(font);
        linestext.setString("LINES : ");
        linestext.setFillColor(sf::Color::White);
        linestext.setCharacterSize(50);
        linestext.setPosition(460, 500);

        name.setFont(font);
        name.setString("NAME : ");
        name.setFillColor(sf::Color::White);
        name.setCharacterSize(50);
        name.setPosition(460, 200);

        scoretext.setFont(font);
        scoretext.setFillColor(sf::Color::White);
        scoretext.setCharacterSize(50);
        scoretext.setPosition(700, 350);

        no_lines.setFont(font);
        no_lines.setFillColor(sf::Color::White);
        no_lines.setCharacterSize(50);
        no_lines.setPosition(700, 500);

        inputname.setFont(font);
        inputname.setFillColor(sf::Color::White);
        inputname.setCharacterSize(50);
        inputname.setPosition(700, 200);

        levels.setFont(font);
        levels.setString("LEVELS : ");
        levels.setFillColor(sf::Color::White);
        levels.setCharacterSize(50);
        levels.setPosition(460, 650);

        noLevels.setFont(font);
        noLevels.setFillColor(sf::Color::White);
        noLevels.setCharacterSize(50);
        noLevels.setPosition(720, 650);

        string inputstring;
        bool istyping = true;

        sf::Event event;
        while (window->isOpen()) {
            elapsed += clock.restart();
            while (window->pollEvent(event)) {
                if (event.type == sf::Event::Closed)
                    window->close();
                if (event.type == sf::Event::KeyPressed) {
                    if (event.key.code == sf::Keyboard::Left) {
                        tetrimino->move_left(grid);
                    }
                    if (event.key.code == sf::Keyboard::Down) {
                        if (tetrimino->move_down(grid)) {
                            clear();
                        }
                        else {
                            dropNewTetrimino();
                        }
                    }
                    if (event.key.code == sf::Keyboard::Right) {
                        tetrimino->move_right(grid);
                    }
                    if (event.key.code == sf::Keyboard::Up) {
                        tetrimino->rotate(grid);
                    }
                }
                if (event.type == sf::Event::TextEntered && istyping) {
                    if (event.text.unicode < 128) {
                        name.setString(inputstring);
                        // Append the input character to the string
                        inputstring += static_cast<char>(event.text.unicode);
                    }
                }
            }
            // incrementing the score lines & levels variable

            scoretext.setString(to_string(score));
            no_lines.setString(to_string(lines));
            noLevels.setString(to_string(level));

            if (elapsed.asSeconds() >= dropDownTime) {
                if (tetrimino->move_down(grid) == true) {
                    // Check if line is complete
                    clear();
                    // Do nothing
                }
                else {
                    dropNewTetrimino();
                }

                elapsed = sf::Time::Zero;
            }
            window->clear();
            window->draw(bg);
            if (screen == 0)
            {
                window->draw(text);
                window->draw(linestext);
                window->draw(name);
                window->draw(scoretext);
                window->draw(no_lines);
                window->draw(inputname);
                window->draw(levels);
                window->draw(noLevels);
                well.Draw();

                for (int i = 0; i < 20; i++) {
                    for (int j = 0; j < 10; j++) {
                        if (grid[i][j] != 0) {
                            colorCell(j, i, grid[i][j]);
                        }
                    }
                }
                tetrimino->draw();
            }
            else if (screen == 1)
            {

            }
           
            window->display();
            for (int j = 0; j < 10; j++) {
                if (grid[0][j] != 0)
                    gameReset();
            }
        }
    }
    void highScores()
    {
        ifstream file("./highscores.txt");
        if (!file.is_open()) {
            // Highscore file does not exist
            for (int i = 0; i < 5; i++) {
                scores[i] = 0;
                name[i] = "";
            }
            return;
        }
        for (int i = 0; i < 5; i++) 
        {
            string line;
            file >> line;
            name[i] = line;
            file >> line;
            scores[i] = stoi(line);
        }
    }
    void savingHighscores()
    {
        ofstream file("./highscores.txt");
        if (!file.is_open()) {
            // Highscore file does not exist
            // Creating the file...
            file.open("./highscores.txt");
        }
        for (int i = 0; i < 5; i++) {
            file << name[i] << endl;
            file << scores[i] << endl;
        }
        file.close();
    }

    ~Game() {
        delete window;
    }
};