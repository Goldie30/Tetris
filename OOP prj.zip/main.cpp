#include <SFML/Graphics.hpp>
#include"Game.h"
#include"well.h"

int main()
{
	
	Game game;
	game.renderGame();
}